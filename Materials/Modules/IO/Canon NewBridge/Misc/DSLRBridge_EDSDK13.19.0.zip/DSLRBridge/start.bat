@echo off
rem Switch to this script's own directory so it works after moving.
cd /d "%~dp0"

"%~dp0DSLRBridge.exe" --backend edsdk --http-port 8080 --photos "%~dp0output\photos"
